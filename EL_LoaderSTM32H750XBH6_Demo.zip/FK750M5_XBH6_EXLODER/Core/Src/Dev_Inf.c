/*
 * Dev_Inf.c
 *
 */
#include "Dev_Inf.h"
#include "quadspi.h"

/* This structure contains information used by ST-LINK Utility to program and erase the device */
/*#if defined (__ICCARM__) */
/*__root struct StorageInfo const StorageInfo  =  { */
/* #else */
__attribute__((used)) __attribute__((section(".StorageInfo")))
struct StorageInfo const StorageInfo = {
//#endif
    "FK750M5_XBH6_QSPI",                  // Device Name + version number
    NOR_FLASH,                           // Device Type
    0x90000000,                          // Device Start Address
	 0x800000,                            // 8 Megabyte Gesamtgröße (W25Q64JV)
	0x100,                               // 256 Bytes Page
	 0xFF,
	/*  MEMORY_FLASH_SIZE,*/                   // Device Size in Bytes
    /*MEMORY_PAGE_SIZE, */                   // Programming Page Size
   /* 0xFF,     */                           // Initial Content of Erased Memory
                               // Initial Content of Erased Memory

    // Specify Size and Address of Sectors (view example below)
    {
    		 { (0x800000 / 0x1000), 0x1000 }, // Sektoren: 2048 * 4KB
    		        { 0x00000000, 0x00000000 }       // End-Marker
    }
};
    		 /*		{


            (MEMORY_FLASH_SIZE / MEMORY_SECTOR_SIZE),  // Sector Numbers,
            (uint32_t) MEMORY_SECTOR_SIZE
        },       //Sector Size

        { 0x00000000, 0x00000000 }
    },


}; */

